# Tổng hai số

**Link:** https://hncode.edu.vn/problem/tonghaiso  
**Rating / Độ khó:** 800  
**Tags:** [`implementation`, `math`]

## 1. Tóm tắt đề bài

Cho hai số nguyên không âm $A$ và $B$.  
Cần in ra tổng $A + B$.

## 2. Phân tích bài toán & Nhận xét quan trọng

Bài toán chỉ yêu cầu thực hiện phép cộng trực tiếp hai số.

Vì $0 \le A, B \le 10^{18}$, tổng lớn nhất là $2 \times 10^{18}$, vẫn nằm trong phạm vi kiểu `long long` của C++.

## 3. Thuật toán cho từng Subtask

> **Kỹ thuật chi tiết:** nhập xuất cơ bản, phép cộng số nguyên.

### Lời giải đầy đủ

**Ý tưởng:**

- Đọc hai số $A$ và $B$.
- Tính $A + B$.
- In kết quả.

**Đánh giá độ phức tạp:**

- Thời gian: $O(1)$.
- Bộ nhớ: $O(1)$.

**Code C++ hoàn chỉnh:**

```cpp
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long A, B;
    cin >> A >> B;
    cout << A + B << '\n';

    return 0;
}
```
