Tổng hai số | tonghaiso | 800 | implementation, math

Cho hai số nguyên không âm $A$ và $B$.

**Yêu cầu:** Hãy tính tổng của hai số đã cho.

#### Input

- Gồm một dòng chứa hai số nguyên không âm $A$ và $B$ $(0 \le A, B \le 10^18)$.

#### Output

- In ra một số nguyên duy nhất là tổng $A + B$.

#### Scoring

- $100\%$ số điểm: Không có ràng buộc gì thêm.

#### Example

!!! question "Test 1"
    ???+ "Input"
        ```sample
        3 5
        ```
    ???+ success "Output"
        ```sample
        8
        ```
    ??? warning "Note"

        Ta có:

        $$
        3 + 5 = 8.
        $$
