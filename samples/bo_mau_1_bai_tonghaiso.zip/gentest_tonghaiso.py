import os
import shutil
import subprocess
import zipfile
from pathlib import Path

NAME = "tonghaiso"
OUT_DIR = Path(NAME)
CPP_PATH = Path(f"_{NAME}_solution.cpp")
EXE_PATH = Path(f"_{NAME}_solution" + (".exe" if os.name == "nt" else ""))

CPP_CODE = r"""
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long A, B;
    cin >> A >> B;
    cout << A + B << '\n';

    return 0;
}
"""

TESTS = [
    # Test mẫu
    "3 5\n",

    # Test nhỏ
    "0 0\n",
    "0 7\n",
    "12 0\n",
    "1 1\n",

    # Test trung bình
    "12345 67890\n",
    "999999 1\n",

    # Test biên lớn
    "1000000000000000000 0\n",
    "0 1000000000000000000\n",
    "1000000000000000000 1000000000000000000\n",
]

def prepare():
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    OUT_DIR.mkdir()
    zip_path = Path(f"{NAME}.zip")
    if zip_path.exists():
        zip_path.unlink()

def compile_solution():
    CPP_PATH.write_text(CPP_CODE, encoding="utf-8")
    cmd = ["g++", "-std=c++17", "-O2", str(CPP_PATH), "-o", str(EXE_PATH)]
    subprocess.run(cmd, check=True)

def run_solution(inp: str) -> str:
    p = subprocess.run(
        [str(EXE_PATH.resolve())],
        input=inp,
        text=True,
        capture_output=True,
        check=True
    )
    return p.stdout.strip() + "\n"

def write_test(idx: int, inp: str, out: str):
    (OUT_DIR / f"{idx:02d}.inp").write_text(inp, encoding="utf-8")
    (OUT_DIR / f"{idx:02d}.out").write_text(out, encoding="utf-8")

def zip_tests():
    with zipfile.ZipFile(f"{NAME}.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for file in sorted(OUT_DIR.iterdir()):
            z.write(file, arcname=str(Path(NAME) / file.name))

def main():
    prepare()
    compile_solution()

    for idx, inp in enumerate(TESTS, 1):
        out = run_solution(inp)
        write_test(idx, inp, out)

    zip_tests()
    print(f"Generated {len(TESTS)} tests in folder '{NAME}' and '{NAME}.zip'")

if __name__ == "__main__":
    main()
